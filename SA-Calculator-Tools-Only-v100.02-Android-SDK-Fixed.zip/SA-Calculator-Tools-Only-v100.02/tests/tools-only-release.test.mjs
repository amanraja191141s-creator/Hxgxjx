import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const read=(p)=>fs.readFileSync(new URL(`../${p}`,import.meta.url),'utf8');
test('tools-only release identity and Android config are aligned',()=>{
 const pkg=JSON.parse(read('package.json')); const manifest=JSON.parse(read('manifest.webmanifest'));
 assert.equal(pkg.version,'2.0.2-v100.02'); assert.equal(pkg.androidVersionCode,1099141);
 assert.equal(manifest.version,pkg.version); assert.equal(JSON.parse(read('capacitor.config.json')).webDir,'www');
});
test('only the 12 intended tool cards are exposed in the catalogue',()=>{
 const html=read('index.html'); const cards=[...html.matchAll(/class="tool-launch-item"[^>]*data-tool-screen="([^"]+)"/g)].map(x=>x[1]);
 assert.equal(cards.length,12); assert.equal(new Set(cards).size,12);
 for(const id of ['salestax','loan','savings','salary','tip','sip','currencies','discount','percent','units','agecalc','bodymetrics']) assert.ok(cards.includes(id),`missing ${id}`);
});
test('tools-only entry point cannot restore Home or Calculator as startup',()=>{
 const js=read('assets/js/app.js');
 assert.match(js,/loadSettingsFromStorage\(\);[\s\S]{0,300}STATE\.startupScreen = 'tools';[\s\S]{0,100}switchScreen\('tools'\);/);
 assert.match(js,/if \(false && s\.startupScreen/);
});
test('legacy home/settings surfaces are not user-visible and tool catalogue is responsive',()=>{
 const css=read('assets/css/tools-only.css');
 for(const selector of ['#screen-viewport > #screen-calc','#screen-viewport > #screen-favorites','#screen-viewport > #screen-settings','#bottom-navigation','#sidebar-drawer']) assert.ok(css.includes(selector));
 assert.match(css,/grid-template-columns:repeat\(3,minmax\(0,1fr\)\)/);
});
test('Android web build copies the tools-only stylesheet and service worker caches it',()=>{
 assert.match(read('scripts/prepare-android-web.mjs'),/assets\/css\/tools-only\.css/);
 assert.match(read('service-worker.js'),/assets\/css\/tools-only\.css/);
});

test('Android setup script creates the native project on a clean checkout and always syncs it',()=>{
 const pkg=JSON.parse(read('package.json'));
 assert.match(pkg.scripts['android:setup'],/test -s android\/app\/src\/main\/AndroidManifest\.xml/);
 assert.match(pkg.scripts['android:setup'],/rm -rf android; npx cap add android/);
 assert.match(pkg.scripts['android:setup'],/npx cap sync android/);
 assert.match(pkg.scripts['android:setup'],/npm run android:brand/);
 assert.match(pkg.scripts['android:apk'],/npm run android:setup/);
});
