import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const js = fs.readFileSync(path.join(root, 'assets/js/app.js'), 'utf8');
const css = fs.readFileSync(path.join(root, 'assets/css/app.css'), 'utf8') + '\n' + fs.readFileSync(path.join(root, 'assets/css/tool-reference-ui.css'), 'utf8');

test('reference launcher uses the three-column categorized tool grid', () => {
  assert.match(html, /Finance &amp; Money/);
  assert.match(html, /Math &amp; General Utilities/);
  assert.match(html, />Health</);
  assert.match(css, /#screen-tools \.tools-reference-grid,#screen-units \.unit-category-grid\s*\{[^}]*grid-template-columns:\s*repeat\(3/);
  assert.match(css, /#screen-tools \.premium-tool-arrow\s*\{\s*display:none/);
});

test('GST screen mirrors Add/Remove, rate presets and state selection', () => {
  const gst = html.match(/<div class="screen" id="screen-salestax">([\s\S]*?)<div class="screen"/)?.[1] || '';
  assert.match(gst, /Original Price/);
  assert.match(gst, /data-gst-mode="exclusive"[^>]*>Add GST/);
  assert.match(gst, /data-gst-mode="inclusive"[^>]*>Remove GST/);
  assert.match(gst, /data-gst-rate="5"/);
  assert.match(gst, /data-gst-rate="18"/);
  assert.match(gst, /data-gst-place="same"[^>]*>In-State/);
  assert.match(gst, /data-gst-place="different"[^>]*>Out-of-State/);
  assert.match(gst, /id="tax-calculate"[^>]*hidden/);
  assert.match(js, /Price Including GST/);
});

test('Loan screen uses numeric tenure and a months/years selector', () => {
  assert.match(html, /id="loan-tenure"[^>]*role="textbox"/);
  assert.match(html, /name="loan-tenure-unit" type="radio" value="months"/);
  assert.match(html, /name="loan-tenure-unit" type="radio" value="years"/);
  assert.match(js, /const tenureValue = readModuleNumber\('loan-tenure'\)/);
  assert.match(js, /tenureUnit === 'years' \? 12 : 1/);
});

test('Saving screen is the three-field goal/rate/period flow', () => {
  const saving = html.match(/<div class="screen" id="screen-savings">([\s\S]*?)<div class="screen"/)?.[1] || '';
  assert.match(saving, /Saving Goal/);
  assert.match(saving, /Rate of Interest/);
  assert.match(saving, /Saving Period/);
  assert.match(saving, /name="sav-period-unit" type="radio" value="months"/);
  assert.match(saving, /name="sav-period-unit" type="radio" value="years"/);
  assert.match(saving, /class="saving-legacy-fields" hidden/);
  assert.match(js, /periodUnit === 'months' \? periodValue \/ 12 : periodValue/);
});

test('Salary, Tip and SIP retain the reference input labels and modes', () => {
  assert.match(html, /<span>Salary amount<\/span>/);
  assert.match(html, /<span>Tax rate<\/span>/);
  assert.match(html, /data-placeholder="Enter bill amount"/);
  assert.match(html, /data-placeholder="Enter tip rate"/);
  assert.match(html, /Number of Person/);
  assert.match(html, /id="sip-tab-calculator"/);
  assert.match(html, /id="sip-tab-delay"/);
});

test('Currency and Unit converters use their reference swap/navigation behavior', () => {
  assert.match(js, /STATE.currentScreen === 'currencies'\)\s*\{\s*document\.getElementById\('btn-cur-swap'\)\?\.click\(\)/);
  assert.match(js, /const showUnitCategories = \(\) =>/);
  assert.match(js, /chooser\.hidden = true/);
  assert.match(js, /if \(workspace\) workspace\.hidden = true/);
  assert.match(js, /setUnitTitle\(`\$\{selectedName\} Calculator`\)/);
  assert.match(html, /class="calc-scrollable" hidden id="unit-converter-workspace"/);
  assert.match(css, /data-screen-context="units"[\s\S]*?data-tool-key="CLR"[\s\S]*?grid-row:1 \/ span 2/);
});

test('Discount and Percentage keep equals-key flow; Currency tall key is a swap', () => {
  assert.match(html, /id="discount-calculate"[^>]*hidden/);
  assert.match(html, /id="percent-calculate"[^>]*hidden/);
  assert.match(js, /isSwapTool = STATE\.currentScreen === 'units' \|\| STATE\.currentScreen === 'currencies'/);
  assert.match(css, /#tool-keypad-dock\[data-screen-context="currencies"\] \.key-btn\.equal-key::after/);
});

test('shared keypad retains 4x4 geometry and safe scroll reserve', () => {
  assert.match(css, /--sa-ref-keypad-height:min\(48\.2dvh,376px\)/);
  assert.match(css, /grid-template-columns:repeat\(4,minmax\(0,1fr\)\)/);
  assert.match(css, /grid-template-rows:repeat\(4,var\(--sa-ref-key-size\)\)/);
  assert.match(css, /padding-bottom:calc\(var\(--sa-ref-keypad-height\) \+ 18px/);
});

test('committed result panels stay hidden until equals and disappear on edits', () => {
  assert.match(css, /#screen-salestax:not\(\[data-tool-calculated="true"\]\) \.tool-result-content/);
  assert.match(css, /#screen-discount:not\(\[data-tool-calculated="true"\]\) \.discount-result-row/);
  assert.match(js, /activeToolScreen\.dataset\.toolCalculated = 'true'/);
  assert.match(js, /screen\.dataset\.toolCalculated = 'false'/);
});
