import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

test('Android workflow avoids removed sdkmanager tools package', () => {
  const yml = readFileSync(new URL('../.github/workflows/main.yml', import.meta.url), 'utf8');
  assert.doesNotMatch(yml, /android-actions\/setup-android@/);
  assert.doesNotMatch(yml, /sdkmanager\s+tools(?:\s|$)/);
  assert.match(yml, /platform-tools/);
  assert.match(yml, /platforms;android-35/);
  assert.match(yml, /build-tools;35\.0\.0/);
  assert.match(yml, /dump badging/);
});
