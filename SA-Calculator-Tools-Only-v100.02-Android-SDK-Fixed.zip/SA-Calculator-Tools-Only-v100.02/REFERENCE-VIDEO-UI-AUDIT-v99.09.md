# SA Calculator v99.09 — Clean source and runtime audit

## Source reviewed
- Previous release archive: `SA-Calculator-v99.08-Clean-Reference-Layers.zip`
- Reference recording carried forward from the prior request: `Screenrecording_20261125_102740.mp4` (720 × 1560 source frame)
- Scope: current release package, stylesheet cascade, keypad lifecycle, 12 retained tool workspaces, web bundle and CI entry points.

## Findings in v99.08 source
1. The archive contained 246 files, including dozens of historical root audit/release documents, old release YAMLs, and a `design-reference` folder that is not required at runtime.
2. The `tests` folder contained 39 tests, while `npm run test:release` executed only 10. The unused legacy test files made the release package noisy and were not CI entry points.
3. `assets/css/app.css` still contained superseded appended visual blocks (`v98.12`, `v98.13`, `v98.15`, `v98.18`).
4. `assets/css/tool-reference-ui.css` contained the old v98.20–v99.07 override stack before the final v99.08 block. This contradicted the earlier claim that the file was already a single layer.
5. `openToolKeypad()` mutated the active field and could push a browser-history entry before checking whether the shared keypad dock existed. If the dock was missing, it could leave an orphan history entry/focus state.

## Changes in v99.09
- Kept the original foundational application CSS and the consolidated global calculator/theme foundation (`v98.17` + `v98.19`); removed superseded appended global visual patches.
- Rebuilt `tool-reference-ui.css` to contain only the final reference UI rules, removing the older versioned cascade blocks.
- Hardened `openToolKeypad()`: it now resolves the keypad dock before changing focus or browser history; the history sequence increments only after `pushState` succeeds; duplicate ARIA assignments removed.
- Removed historical root release/audit documents, old standalone v99.07/v99.08 YAMLs, historical design-reference JSON, and tests not invoked by the release suite.
- Preserved all 12 requested tool workspaces, calculator/scientific calculator, history, favorites, settings, localization, theme logic, brand assets, currency/unit data and active release test entry points.
- Rebuilt `www/` from authoritative root assets and kept root/web mirrors byte-identical.

## Preserved tool scope
Currency Converter, Unit Converter, GST Calculator, Loan Calculator, Saving Calculator, Salary Calculator, Tip Calculator, SIP Calculator, Discount Calculator, Percentage Calculator, Age Calculator and BMI Calculator.

## Explicit limitations
The uploaded reference is a video recording, but this source audit does not claim a physical Android-device pixel-diff or real-touch test. Automated source tests and web build are separate from a remote GitHub Actions APK build. Currency conversion still requires a working network/provider or its built-in fallback rates.
