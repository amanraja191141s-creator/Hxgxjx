# Release v100.02 — Android SDK workflow repair

## Root cause from the supplied GitHub Actions log
The job failed inside `android-actions/setup-android@v3`, before the project's own SDK install step. The action invoked `sdkmanager tools`; current Android SDK repositories no longer provide the obsolete `tools` package, so sdkmanager exited with code 1.

## Fix
- Removed the failing `android-actions/setup-android@v3` action.
- Uses the GitHub-hosted runner's preinstalled Android SDK and discovers the actual sdkmanager path.
- Explicitly accepts SDK licences non-interactively.
- Installs only required packages: platform-tools, Android platform 35 and build-tools 35.0.0.
- Verifies adb, aapt and platform installation before continuing.
- Keeps Java 21, Node 22, Capacitor 7.4.3, tools-only app, all 12 tools and APK artifact upload.
- Adds explicit APK package-name and versionCode checks using the pinned aapt binary.
