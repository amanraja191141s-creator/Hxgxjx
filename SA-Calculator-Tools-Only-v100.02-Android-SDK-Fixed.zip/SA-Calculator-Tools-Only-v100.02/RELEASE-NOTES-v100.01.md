# Release v100.01 — Android build setup repair

- Bumped app version and Android versionCode to a new upgrade-safe release identity.
- Added `android:setup`, which creates the Capacitor Android project on clean checkouts, syncs web assets, and applies native branding/version configuration.
- Updated `android:apk` to run the full setup automatically before Gradle.
- Rebuilt GitHub Actions workflow with explicit Android SDK licence acceptance/package installation, clean-checkout native project generation, Gradle wrapper checks, APK verification and artifact upload.
- Kept the 12-tool catalogue and tools-only startup behavior.
